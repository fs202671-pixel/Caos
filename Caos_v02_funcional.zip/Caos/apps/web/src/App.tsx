import { useEffect, useMemo, useState } from 'react';
import { Send, Wand2, FolderPlus, Puzzle, Sparkles, Timer } from 'lucide-react';
import type { MemoryItem, Message, Mode, PlannedAction } from './types';
import { tools } from './data/tools';
import { generateReply, plan } from './services/agent';
import { sendChat, getMemory, createProject, createPlugin, createSkill, startModeOn } from './services/api';
import { Sidebar } from './components/Sidebar';
import { Sphere } from './components/Sphere';

const starter: Message[] = [
  {
    id: 1,
    role: 'ai',
    mode: 'chat',
    text: 'Caos v0.2 iniciado. Agora eu tenho backend local, memória persistente, criação de projetos, plugins, habilidades e ModeON inicial.'
  }
];

export default function App() {
  const [mode, setMode] = useState<Mode>('chat');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>(starter);
  const [actions, setActions] = useState<PlannedAction[]>([]);
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [apiOnline, setApiOnline] = useState(true);

  const tool = tools.find((item) => item.id === mode)!;

  useEffect(() => {
    getMemory()
      .then(setMemories)
      .catch(() => setApiOnline(false));
  }, []);

  const thoughts = useMemo(() => [
    `modo: ${tool.label}`,
    `habilidade: ${tool.description}`,
    `api: ${apiOnline ? 'online' : 'offline/simulado'}`,
    `ações planejadas: ${actions.length}`,
    `memórias ativas: ${memories.length}`
  ], [actions.length, apiOnline, memories.length, tool]);

  async function refreshMemory() {
    try {
      setMemories(await getMemory());
      setApiOnline(true);
    } catch {
      setApiOnline(false);
    }
  }

  async function send() {
    if (!input.trim()) return;

    const text = input;
    const user: Message = { id: Date.now(), role: 'user', text, mode };
    setMessages((prev) => [...prev, user]);
    setInput('');

    try {
      const result = await sendChat(mode, text);
      const ai: Message = { id: Date.now() + 1, role: 'ai', text: result.reply, mode };
      setMessages((prev) => [...prev, ai]);
      setActions(result.actions || []);
      setApiOnline(true);
      refreshMemory();
    } catch {
      const fallbackActions = plan(mode, text);
      const ai: Message = { id: Date.now() + 1, role: 'ai', text: generateReply(mode, text), mode };
      setMessages((prev) => [...prev, ai]);
      setActions(fallbackActions);
      setApiOnline(false);
    }
  }

  async function quickCreate(kind: 'project' | 'plugin' | 'skill' | 'modeon') {
    const name = input.trim() || `Novo ${kind}`;
    try {
      if (kind === 'project') await createProject(name, 'Criado pela interface do Caos.');
      if (kind === 'plugin') await createPlugin(name, 'Plugin criado pela interface do Caos.');
      if (kind === 'skill') await createSkill(name, 'Habilidade criada pela interface do Caos.');
      if (kind === 'modeon') await startModeOn(name, 25);

      const ai: Message = {
        id: Date.now(),
        role: 'ai',
        mode,
        text: `${kind} criado/ativado com sucesso no backend local.`
      };
      setMessages((prev) => [...prev, ai]);
      refreshMemory();
    } catch {
      setMessages((prev) => [...prev, {
        id: Date.now(),
        role: 'ai',
        mode,
        text: 'Não consegui executar no backend. Verifique se a API está rodando na porta 8000.'
      }]);
    }
  }

  return (
    <main className="shell">
      <Sidebar active={mode} onChange={setMode} />

      <section className="main">
        <header className="topbar">
          <div>
            <span className="eyebrow">Modo ativo</span>
            <h1>{tool.label}</h1>
            <p>{tool.description}</p>
          </div>
          <button className="pill" onClick={() => quickCreate('skill')}><Wand2 size={17} /> Criar habilidade</button>
        </header>

        <section className="hero">
          <Sphere mode={mode} />
          <div className="panel thoughts">
            <strong>Pensamento visível</strong>
            {thoughts.map((item) => <p key={item}>// {item}</p>)}
          </div>
          <div className="panel actions">
            <strong>Ações</strong>
            {actions.map((action) => (
              <article key={action.id} className={`action ${action.risk}`}>
                <b>{action.title}</b>
                <p>{action.description}</p>
                <span>{action.risk} · {action.status}</span>
              </article>
            ))}
            {!actions.length && <p>Nenhuma ação planejada ainda.</p>}
          </div>
        </section>

        <section className="toolbelt">
          <button onClick={() => quickCreate('project')}><FolderPlus size={17} /> Criar projeto</button>
          <button onClick={() => quickCreate('plugin')}><Puzzle size={17} /> Criar plugin</button>
          <button onClick={() => quickCreate('skill')}><Sparkles size={17} /> Criar habilidade</button>
          <button onClick={() => quickCreate('modeon')}><Timer size={17} /> ModeON</button>
        </section>

        <section className="work">
          <div className="chat">
            <div className="messages">
              {messages.map((message) => (
                <article key={message.id} className={`message ${message.role}`}>
                  <span>{message.role === 'ai' ? 'Caos' : 'Você'} · {message.mode}</span>
                  <p>{message.text}</p>
                </article>
              ))}
            </div>
            <div className="composer">
              <input
                value={input}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => event.key === 'Enter' && send()}
                placeholder={`Dê uma ordem em ${tool.label}...`}
              />
              <button onClick={send}><Send size={18} /></button>
            </div>
          </div>

          <aside className="memory">
            <strong>Memória e espaços</strong>
            {memories.slice(-8).map((memory) => (
              <article key={memory.id}>
                <span>{memory.kind}</span>
                <p>{memory.text}</p>
              </article>
            ))}
            {!memories.length && <p className="muted">Sem memórias carregadas ainda.</p>}
          </aside>
        </section>
      </section>
    </main>
  );
}

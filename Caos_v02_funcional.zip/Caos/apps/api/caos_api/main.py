from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Literal, Optional
from pathlib import Path
import json
from datetime import datetime

app = FastAPI(title="Caos API", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Mode = Literal[
    "chat", "code", "projects", "teacher", "memory", "plugins", "skills",
    "automation", "image", "voice", "modeon", "dev"
]

ROOT = Path(__file__).resolve().parents[3]
DATA_DIR = ROOT / "data"
WORKSPACE = ROOT / "workspace"
MEMORY_FILE = DATA_DIR / "memory.json"
LOG_FILE = DATA_DIR / "events.log"

for directory in [
    DATA_DIR,
    WORKSPACE / "projects",
    WORKSPACE / "plugins",
    WORKSPACE / "skills",
]:
    directory.mkdir(parents=True, exist_ok=True)

class ChatRequest(BaseModel):
    mode: Mode
    message: str

class MemoryEntry(BaseModel):
    kind: str
    text: str

class CreateThingRequest(BaseModel):
    name: str
    description: Optional[str] = ""

class FocusSessionRequest(BaseModel):
    minutes: int = 25
    goal: str = "Executar tarefa principal"

def now():
    return datetime.utcnow().isoformat()

def safe_slug(name: str):
    slug = "".join(ch for ch in name.strip().replace(" ", "-") if ch.isalnum() or ch in "-_").strip("-_")
    return slug or "novo-item"

def load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def save_json(path: Path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def log_event(kind: str, payload: dict):
    LOG_FILE.parent.mkdir(exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"at": now(), "kind": kind, "payload": payload}, ensure_ascii=False) + "\n")

def add_memory(kind: str, text: str):
    items = load_json(MEMORY_FILE, [])
    item = {"id": len(items) + 1, "kind": kind, "text": text, "createdAt": now()}
    items.append(item)
    save_json(MEMORY_FILE, items)
    return item

def classify_risk(message: str):
    text = message.lower()
    if any(word in text for word in ["apagar", "deletar", "excluir", "remover tudo", "limpar tudo"]):
        return "high"
    if any(word in text for word in ["criar", "editar", "modificar", "arquivo", "plugin", "projeto"]):
        return "medium"
    return "low"

def infer_actions(mode: Mode, message: str):
    risk = classify_risk(message)
    actions = []

    if mode == "projects" or "crie um site" in message.lower() or "crie um app" in message.lower():
        actions.append({
            "id": "create-project",
            "title": "Criar projeto",
            "description": "Gerar estrutura em workspace/projects.",
            "risk": "medium",
            "status": "needs_confirmation",
        })

    if mode == "plugins" or "plugin" in message.lower():
        actions.append({
            "id": "create-plugin",
            "title": "Criar plugin",
            "description": "Gerar manifesto e arquivo base em workspace/plugins.",
            "risk": "medium",
            "status": "needs_confirmation",
        })

    if mode == "skills" or "habilidade" in message.lower():
        actions.append({
            "id": "create-skill",
            "title": "Criar habilidade",
            "description": "Gerar especificação em workspace/skills.",
            "risk": "medium",
            "status": "needs_confirmation",
        })

    if risk == "high":
        actions.append({
            "id": "danger",
            "title": "Ação destrutiva detectada",
            "description": "Exige confirmação explícita e escopo exato.",
            "risk": "high",
            "status": "needs_confirmation",
        })

    if not actions:
        actions.append({
            "id": "reply",
            "title": "Responder",
            "description": "Responder sem alterar arquivos.",
            "risk": "low",
            "status": "ready",
        })

    return actions

def reply_for(mode: Mode, message: str):
    base = {
        "chat": "Vou conversar mantendo contexto.",
        "code": "Vou tratar como tarefa de programação.",
        "projects": "Vou transformar isso em estrutura de projeto.",
        "teacher": "Vou ensinar em etapas, com prática e revisão.",
        "memory": "Vou consultar e organizar memória.",
        "plugins": "Vou estruturar um plugin para o Caos.",
        "skills": "Vou criar uma habilidade reutilizável.",
        "automation": "Vou transformar em fluxo de automação.",
        "image": "Vou preparar direção visual.",
        "voice": "Vou preparar expressão de voz.",
        "modeon": "Vou focar em execução e disciplina.",
        "dev": "Vou analisar arquitetura, risco e runtime.",
    }[mode]
    return f"{base} Pedido recebido: {message}"

@app.get("/health")
def health():
    return {"status": "ok", "service": "caos-api", "version": "0.2.0"}

@app.post("/chat")
def chat(request: ChatRequest):
    actions = infer_actions(request.mode, request.message)
    memory = add_memory("event", f"[{request.mode}] {request.message}")
    log_event("chat", {"mode": request.mode, "message": request.message, "actions": actions})
    return {
        "reply": reply_for(request.mode, request.message),
        "mode": request.mode,
        "actions": actions,
        "memory": memory,
    }

@app.get("/memory")
def memory_list(q: str = ""):
    items = load_json(MEMORY_FILE, [])
    if q:
        needle = q.lower()
        items = [item for item in items if needle in item.get("text", "").lower() or needle in item.get("kind", "").lower()]
    return {"items": items}

@app.post("/memory")
def memory_add(entry: MemoryEntry):
    item = add_memory(entry.kind, entry.text)
    log_event("memory.add", item)
    return {"saved": True, "item": item}

@app.delete("/memory/{item_id}")
def memory_delete(item_id: int):
    items = load_json(MEMORY_FILE, [])
    new_items = [item for item in items if item.get("id") != item_id]
    save_json(MEMORY_FILE, new_items)
    log_event("memory.delete", {"id": item_id})
    return {"deleted": len(items) != len(new_items)}

@app.post("/projects")
def create_project(payload: CreateThingRequest):
    slug = safe_slug(payload.name)
    project_dir = WORKSPACE / "projects" / slug
    project_dir.mkdir(parents=True, exist_ok=True)

    files = {
        "README.md": f"# {payload.name}\n\n{payload.description or 'Projeto criado pelo Caos.'}\n",
        "index.html": "<!doctype html><html><head><title>Projeto Caos</title></head><body><div id='app'>Novo projeto</div></body></html>\n",
        "src/main.js": "console.log('Projeto criado pelo Caos');\n",
    }

    for rel, content in files.items():
        path = project_dir / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    log_event("project.create", {"name": payload.name, "path": str(project_dir)})
    return {"created": True, "name": payload.name, "path": str(project_dir), "files": list(files.keys())}

@app.post("/plugins")
def create_plugin(payload: CreateThingRequest):
    slug = safe_slug(payload.name)
    plugin_dir = WORKSPACE / "plugins" / slug
    plugin_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "name": payload.name,
        "version": "0.1.0",
        "description": payload.description or "Plugin criado pelo Caos.",
        "permissions": [],
        "commands": [],
    }

    (plugin_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    (plugin_dir / "plugin.py").write_text(
        "def run(input_text: str):\n    return {'ok': True, 'output': input_text}\n",
        encoding="utf-8",
    )

    log_event("plugin.create", manifest)
    return {"created": True, "manifest": manifest, "path": str(plugin_dir)}

@app.post("/skills")
def create_skill(payload: CreateThingRequest):
    slug = safe_slug(payload.name)
    skill_dir = WORKSPACE / "skills" / slug
    skill_dir.mkdir(parents=True, exist_ok=True)

    spec = {
        "name": payload.name,
        "description": payload.description or "Habilidade criada pelo Caos.",
        "input": "texto do usuário",
        "output": "resultado estruturado",
        "examples": [],
    }

    (skill_dir / "skill.json").write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    (skill_dir / "README.md").write_text(f"# {payload.name}\n\n{spec['description']}\n", encoding="utf-8")

    log_event("skill.create", spec)
    return {"created": True, "skill": spec, "path": str(skill_dir)}

@app.get("/workspace")
def list_workspace():
    result = {}
    for section in ["projects", "plugins", "skills"]:
        folder = WORKSPACE / section
        result[section] = [p.name for p in folder.iterdir() if p.is_dir()]
    return result

@app.post("/modeon/session")
def start_focus_session(payload: FocusSessionRequest):
    session = {
        "goal": payload.goal,
        "minutes": payload.minutes,
        "state": "ON",
        "startedAt": now(),
        "message": "ModeON ativo. Execute o essencial agora.",
    }
    log_event("modeon.session", session)
    add_memory("event", f"ModeON iniciado: {payload.goal} por {payload.minutes} minutos")
    return session

@app.get("/logs")
def logs():
    if not LOG_FILE.exists():
        return {"events": []}
    lines = LOG_FILE.read_text(encoding="utf-8").splitlines()[-100:]
    return {"events": [json.loads(line) for line in lines if line.strip()]}

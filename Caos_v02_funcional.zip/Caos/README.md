# Caos

Caos é uma aplicação de IA pessoal com visual inspirado em sistemas de chat modernos, mas com identidade própria: uma esfera viva, espaços de habilidades, ferramentas, memória, criação de projetos, plugins e modo professor.

O foco do projeto é permitir que o usuário oriente a IA para criar, programar, explicar, automatizar, estudar, modificar projetos e evoluir habilidades, sempre com autorização e direção do usuário.

## Ideia central

A IA deve:

- Obedecer ao usuário dentro de limites seguros.
- Fazer somente o que foi pedido.
- Explicar quando uma ação exige confirmação.
- Criar sites, apps, plugins, habilidades, textos, aulas, imagens e fluxos.
- Modificar o próprio código somente quando o usuário pedir e dentro do workspace controlado.
- Manter memória e contexto.
- Ter espaços visuais para cada habilidade/ferramenta.
- Funcionar primeiro como app local, preparado para conectar LLMs reais depois.

## Estrutura

```txt
apps/web      interface principal estilo ChatGPT + identidade Caos
apps/api      backend local FastAPI
packages/core regras fixas, permissões e segurança
packages/agent roteamento da IA por modo
packages/runtime execução controlada e plano de ações
packages/memory memória local e busca
packages/skills sistema de habilidades
packages/plugins sistema de plugins
packages/projects criação de apps/sites/projetos
packages/modeon módulo de foco e disciplina
workspace     projetos, plugins e habilidades criados pela IA
docs          visão, arquitetura e manifesto
```

## Como rodar o frontend

```bash
cd apps/web
npm install
npm run dev
```

## Como rodar o backend

```bash
cd apps/api
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt
uvicorn caos_api.main:app --reload --port 8000
```

## Estado atual

Este pacote é a base completa reorganizada do Caos. Ele já inclui:

- UI principal funcional.
- Sidebar de modos.
- Esfera viva.
- Chat simulado com roteamento por habilidade.
- Painel de ferramentas.
- Painel de ações planejadas.
- Motor de permissões.
- Backend local inicial.
- Sistema de memória em arquivo JSON.
- Criador de projetos e plugins em formato seguro.


## Versão v0.2

Esta versão adiciona:

- Frontend conectado ao backend.
- API local com CORS.
- Memória persistente em `apps/api/data/memory.json`.
- Logs em `apps/api/data/events.log`.
- Criação real de projetos em `workspace/projects`.
- Criação real de plugins em `workspace/plugins`.
- Criação real de habilidades em `workspace/skills`.
- Endpoint de ModeON.
- Painel de ações planejadas.
- Toolbelt com botões de criação rápida.

## Percentual funcional atual

**35% do aplicativo-base.**

Não significa 35% da visão final completa, porque a visão final é grande: LLM local, RAG, sandbox, plugins executáveis, voz, imagem, automação e ModeON completo ainda serão fases seguintes.

export type RuntimeAction = {
  id: string;
  title: string;
  risk: 'low' | 'medium' | 'high';
};

export function validate(action: RuntimeAction) {
  return {
    allowed: action.risk === 'low',
    needsConfirmation: action.risk !== 'low',
    action
  };
}

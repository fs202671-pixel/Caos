export type AgentMode =
  | 'chat'
  | 'code'
  | 'projects'
  | 'teacher'
  | 'memory'
  | 'plugins'
  | 'skills'
  | 'automation'
  | 'image'
  | 'voice'
  | 'modeon'
  | 'dev';

export function inferIntent(mode: AgentMode, input: string) {
  if (mode === 'projects') return 'create_project';
  if (mode === 'plugins') return 'create_plugin';
  if (mode === 'skills') return 'create_skill';
  if (mode === 'teacher') return 'teach';
  if (mode === 'code') return 'code';
  return input.includes('@memoria') ? 'memory_query' : 'chat';
}

export type RiskLevel = 'low' | 'medium' | 'high';

export function classifyRisk(text: string): RiskLevel {
  const value = text.toLowerCase();
  if (value.includes('apagar') || value.includes('deletar') || value.includes('excluir')) return 'high';
  if (value.includes('criar') || value.includes('editar') || value.includes('executar')) return 'medium';
  return 'low';
}

export function requiresConfirmation(risk: RiskLevel): boolean {
  return risk !== 'low';
}

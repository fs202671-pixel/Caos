export type FocusState = 'OFF' | 'ON' | 'DISTRACTED' | 'RECOVERING';

export function nextFocusMessage(state: FocusState): string {
  if (state === 'ON') return 'Estado ON ativo. Continue executando.';
  if (state === 'DISTRACTED') return 'Distração detectada. Volte para a tarefa.';
  if (state === 'RECOVERING') return 'Recuperando foco. Um passo de cada vez.';
  return 'Ative o ModeON quando estiver pronto para executar.';
}

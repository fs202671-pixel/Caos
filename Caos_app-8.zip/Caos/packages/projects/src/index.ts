export type ProjectTemplate = {
  name: string;
  files: Array<{ path: string; content: string }>;
};

export function createReactAppTemplate(name: string): ProjectTemplate {
  return {
    name,
    files: [
      { path: 'README.md', content: `# ${name}\n` },
      { path: 'src/App.tsx', content: 'export default function App(){ return <main>Novo app</main>; }' }
    ]
  };
}

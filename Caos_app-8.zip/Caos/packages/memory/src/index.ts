export type MemoryRecord = {
  id: string;
  kind: 'user' | 'project' | 'lesson' | 'system' | 'event';
  text: string;
  createdAt: string;
};

export function createRecord(kind: MemoryRecord['kind'], text: string): MemoryRecord {
  return {
    id: String(Date.now()),
    kind,
    text,
    createdAt: new Date().toISOString()
  };
}

export function search(records: MemoryRecord[], query: string) {
  const needle = query.toLowerCase();
  return records.filter((record) => record.text.toLowerCase().includes(needle));
}

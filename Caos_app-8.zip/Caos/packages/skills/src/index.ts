export type Skill = {
  name: string;
  description: string;
  inputSchema: string;
  outputSchema: string;
  examples: string[];
};

export function createSkill(name: string, description: string): Skill {
  return {
    name,
    description,
    inputSchema: 'texto livre do usuário',
    outputSchema: 'resposta estruturada da habilidade',
    examples: []
  };
}

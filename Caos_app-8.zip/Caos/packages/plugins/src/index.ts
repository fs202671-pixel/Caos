export type PluginManifest = {
  name: string;
  version: string;
  permissions: string[];
  commands: string[];
};

export function createPluginManifest(name: string): PluginManifest {
  return {
    name,
    version: '0.1.0',
    permissions: [],
    commands: []
  };
}

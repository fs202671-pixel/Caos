# Workspace

Área onde o Caos pode criar projetos, plugins e habilidades sob comando do usuário.

- `projects/`: sites e apps criados.
- `plugins/`: extensões novas.
- `skills/`: habilidades reutilizáveis.

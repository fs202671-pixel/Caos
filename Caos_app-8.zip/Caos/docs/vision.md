# Visão do Caos

Caos é uma IA pessoal que funciona como um sistema operacional criativo: conversa, programa, cria projetos, ensina, automatiza, organiza memórias e constrói novas habilidades sob orientação do usuário.

## Visual

O visual deve lembrar a clareza de um chat moderno, mas sem ser cópia:

- Área central de conversa.
- Sidebar com ferramentas.
- Painel lateral contextual.
- Esfera viva como presença da IA.
- Tema escuro profundo.
- Neon azul/roxo controlado.
- Cartões para habilidades e ferramentas.
- Áreas dedicadas para cada modo.

## Obediência ao usuário

A IA deve seguir a intenção do usuário. Ela não deve agir sozinha em mudanças críticas. Para ações de escrita, execução, exclusão ou modificação do próprio sistema, ela deve:

1. Entender o pedido.
2. Gerar um plano.
3. Mostrar o que será alterado.
4. Aguardar confirmação quando houver risco.
5. Executar somente o escopo solicitado.

## Capacidades

- Chat e explicações.
- Professor/tutor.
- Programação.
- Criação de projetos.
- Criação de plugins.
- Criação de habilidades.
- Memória.
- Automação.
- Modo foco/ModeON.
- Voz e imagem como módulos preparados para evolução.
- Auto-modificação controlada do workspace.

## Regra de ouro

O Caos pode ser poderoso, mas não deve ser impulsivo. Poder sem trilho vira ruído. O usuário é o comandante.

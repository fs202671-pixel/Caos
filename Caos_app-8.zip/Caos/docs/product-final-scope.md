# Escopo da primeira versão do Caos

Este documento organiza o caminho até a primeira versão completa do aplicativo Caos.

## Filosofia

O Caos é uma IA pessoal com visual de chat moderno, mas com espaços próprios para ferramentas, habilidades, criação de projetos, memória, plugins, automação, estudo e desenvolvimento.

A IA deve seguir a ordem do usuário. Ela pode criar, modificar e expandir o próprio ambiente, mas mudanças em arquivos, plugins, habilidades e projetos passam por ações estruturadas.

## Áreas do aplicativo

- Chat central.
- Código.
- Projetos.
- Professor.
- Memória.
- Plugins.
- Habilidades.
- Automação.
- Imagem.
- Voz.
- ModeON.
- Dev Mode.

## Requisitos da primeira versão

### Interface
- Sidebar com modos.
- Chat.
- Esfera viva.
- Toolbelt de ações.
- Explorador de arquivos.
- Painel de memória.
- Painel de ações.
- Painel de workspace.

### Backend
- API local.
- Memória persistente.
- Logs.
- Criação de projetos.
- Criação de plugins.
- Criação de habilidades.
- Leitura de arquivos do workspace.
- Escrita controlada de arquivos.
- Templates de projetos.
- Integração preparada com Ollama.

### IA
- Roteador de modos.
- Planejamento de ações.
- Classificação de risco.
- Contexto com memória.
- Resposta local simulada quando não houver LLM real.
- LLM local opcional.

### Segurança
- Não executar texto bruto como comando.
- Não apagar em massa sem confirmação.
- Modificar somente workspace por padrão.
- Registrar ações em log.

## Status atual

A primeira versão ainda não está finalizada, mas agora já possui base de app real:

- Frontend conectado ao backend.
- Memória real em JSON.
- Criação real de projetos, plugins e habilidades.
- Workspace navegável.
- Leitura e escrita controlada de arquivos.
- Templates iniciais de projetos.
- Integração preparada para Ollama.

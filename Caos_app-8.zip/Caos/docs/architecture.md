# Arquitetura

```txt
User
 ↓
Web UI
 ↓
Agent Router
 ↓
Core Permission Engine
 ↓
Runtime Planner
 ↓
Tools / Skills / Projects / Plugins
 ↓
Workspace
```

## core

Regras estáveis:

- Classificar risco.
- Decidir se precisa confirmação.
- Bloquear alterações fora do escopo.
- Impedir exclusão destrutiva sem confirmação.

## agent

Interpreta intenção e modo ativo:

- chat
- code
- projects
- teacher
- memory
- plugins
- skills
- automation
- modeon
- dev

## runtime

Transforma pedidos em ações planejadas:

- create_project
- create_plugin
- create_skill
- edit_file
- explain
- teach
- search_memory
- run_flow

## workspace

Área onde a IA pode criar coisas sob comando:

- `workspace/projects`
- `workspace/plugins`
- `workspace/skills`

## Segurança prática

A IA nunca deve interpretar texto bruto como comando de sistema. Tudo vira ação estruturada primeiro.

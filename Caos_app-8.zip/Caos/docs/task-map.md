# Mapa de tarefas do Caos

## Status geral desta versão

Estimativa funcional honesta: **48% do aplicativo-base**.

Isso significa que a estrutura principal já existe e vários fluxos reais foram implementados, mas ainda faltam integração com LLM real, sandbox completo, voz/imagem reais e automações profundas.

## Tarefas concluídas nesta versão v0.2

- [x] Organizar arquitetura local.
- [x] Criar frontend React/Vite.
- [x] Criar visual estilo chat moderno com identidade própria.
- [x] Criar esfera visual.
- [x] Criar sidebar de modos/habilidades.
- [x] Criar backend FastAPI.
- [x] Conectar frontend ao backend via API client.
- [x] Criar memória persistente em JSON.
- [x] Criar tela/painel de memória no app.
- [x] Criar endpoint para chat.
- [x] Criar roteador de modos.
- [x] Criar planejador de ações.
- [x] Criar classificador de risco.
- [x] Criar criação real de projetos no workspace.
- [x] Criar criação real de plugins no workspace.
- [x] Criar criação real de habilidades no workspace.
- [x] Criar endpoint de listagem do workspace.
- [x] Criar módulo Professor.
- [x] Criar módulo ModeON inicial.
- [x] Criar documentação de visão.
- [x] Criar documentação de arquitetura.
- [x] Criar mapa de tarefas.

## Próximas tarefas

### Fase 1: IA real
- [ ] Conectar LLM local via Ollama.
- [ ] Conectar LLM via API opcional.
- [ ] Adicionar streaming de respostas.
- [ ] Criar prompt de sistema por modo.
- [ ] Criar contexto com memória antes da resposta.

### Fase 2: Projetos reais
- [x] Editor de arquivos no frontend.
- [x] Explorador visual estilo VS Code inicial.
- [ ] Preview de arquivos.
- [ ] Diff antes de salvar.
- [ ] Aplicar alterações com confirmação.
- [ ] Gerar apps completos por template.

### Fase 3: Plugins e habilidades
- [ ] Instalar plugin pela interface.
- [ ] Ativar/desativar plugin.
- [ ] Rodar habilidade pelo chat.
- [ ] Criar biblioteca de habilidades.
- [ ] Criar permissões por plugin.

### Fase 4: Segurança e runtime
- [ ] Sandbox real.
- [ ] Logs imutáveis.
- [ ] Histórico de ações.
- [ ] Replay de decisões.
- [ ] Rollback de alterações.
- [ ] Firewall semântico.

### Fase 5: Multimodal
- [ ] Voz TTS.
- [ ] STT/microfone.
- [ ] Galeria de vozes.
- [ ] Imagem por modelo/API.
- [ ] Galeria de imagens.

### Fase 6: ModeON
- [ ] Sessões de foco.
- [ ] Streak.
- [ ] Histórico de falhas.
- [ ] Bloqueio de distrações.
- [ ] Alertas adaptativos.

### Fase 7: Produto final
- [ ] Login.
- [ ] Configurações completas.
- [ ] Exportar/importar IA.
- [ ] Tema e personalização.
- [ ] Deploy.
- [ ] Testes automatizados.


## Tarefas concluídas no bloco atual

- [x] Remover numeração pública de versões intermediárias.
- [x] Adicionar escopo da primeira versão.
- [x] Criar explorador de arquivos do workspace.
- [x] Criar editor de arquivos simples.
- [x] Adicionar leitura de arquivos no backend.
- [x] Adicionar escrita controlada de arquivos no backend.
- [x] Adicionar template React para projetos.
- [x] Adicionar execução inicial de plugins.
- [x] Adicionar execução inicial de habilidades.
- [x] Preparar integração com Ollama local.
- [x] Adicionar toggle de LLM local na interface.

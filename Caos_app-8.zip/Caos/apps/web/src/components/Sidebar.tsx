import { Bot, Brain, Code2, GraduationCap, Hammer, Image, Mic, Puzzle, Radar, Shield, Sparkles, Workflow } from 'lucide-react';
import type { Mode } from '../types';
import { tools } from '../data/tools';

const icons: Record<Mode, JSX.Element> = {
  chat: <Bot size={18} />,
  code: <Code2 size={18} />,
  projects: <Hammer size={18} />,
  teacher: <GraduationCap size={18} />,
  memory: <Brain size={18} />,
  plugins: <Puzzle size={18} />,
  skills: <Sparkles size={18} />,
  automation: <Workflow size={18} />,
  image: <Image size={18} />,
  voice: <Mic size={18} />,
  modeon: <Radar size={18} />,
  dev: <Shield size={18} />
};

export function Sidebar({ active, onChange }: { active: Mode; onChange: (mode: Mode) => void }) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">C</div>
        <div>
          <strong>Caos</strong>
          <span>AI System</span>
        </div>
      </div>

      <nav className="mode-list">
        {tools.map((tool) => (
          <button key={tool.id} className={active === tool.id ? 'mode active' : 'mode'} onClick={() => onChange(tool.id)}>
            {icons[tool.id]}
            <span>{tool.label}</span>
          </button>
        ))}
      </nav>

      <div className="side-note">
        <strong>Regra</strong>
        <p>A IA cria e modifica sob ordem do usuário. Ações de risco mostram plano antes.</p>
      </div>
    </aside>
  );
}

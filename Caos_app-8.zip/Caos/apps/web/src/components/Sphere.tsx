import type { Mode } from '../types';

const modeClass: Record<Mode, string> = {
  chat: 'blue',
  code: 'white',
  projects: 'violet',
  teacher: 'green',
  memory: 'emerald',
  plugins: 'amber',
  skills: 'pink',
  automation: 'orange',
  image: 'purple',
  voice: 'indigo',
  modeon: 'red',
  dev: 'white'
};

export function Sphere({ mode }: { mode: Mode }) {
  return (
    <div className={`sphere ${modeClass[mode]}`}>
      <div className="sphere-core" />
      <div className="sphere-ring one" />
      <div className="sphere-ring two" />
      <div className="sphere-face">
        <span />
        <span />
      </div>
    </div>
  );
}

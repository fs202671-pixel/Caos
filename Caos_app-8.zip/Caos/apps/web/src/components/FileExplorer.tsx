import { useEffect, useState } from 'react';
import { File, Folder, RefreshCw, Save } from 'lucide-react';
import { listFiles, readFile, writeFile, type WorkspaceItem } from '../services/api';

export function FileExplorer() {
  const [path, setPath] = useState('');
  const [items, setItems] = useState<WorkspaceItem[]>([]);
  const [selected, setSelected] = useState('');
  const [content, setContent] = useState('');
  const [status, setStatus] = useState('');

  async function refresh(nextPath = path) {
    const result = await listFiles(nextPath);
    setPath(nextPath);
    setItems(result);
  }

  async function openItem(item: WorkspaceItem) {
    if (item.type === 'folder') {
      refresh(item.path || item.name);
      return;
    }

    const filePath = item.path || item.name;
    setSelected(filePath);
    try {
      setContent(await readFile(filePath));
      setStatus(`Arquivo aberto: ${filePath}`);
    } catch {
      setStatus('Não consegui abrir o arquivo.');
    }
  }

  async function save() {
    if (!selected) return;
    await writeFile(selected, content);
    setStatus(`Arquivo salvo: ${selected}`);
  }

  useEffect(() => {
    refresh('');
  }, []);

  return (
    <section className="file-explorer">
      <div className="explorer-head">
        <strong>Workspace</strong>
        <button onClick={() => refresh('')}><RefreshCw size={15} /> raiz</button>
      </div>

      {path && <button className="breadcrumb" onClick={() => refresh('')}>/workspace/{path}</button>}

      <div className="explorer-grid">
        <div className="file-list">
          {items.map((item) => (
            <button key={item.path || item.name} onClick={() => openItem(item)}>
              {item.type === 'folder' ? <Folder size={15} /> : <File size={15} />}
              <span>{item.name}</span>
            </button>
          ))}
          {!items.length && <p className="muted">Workspace vazio.</p>}
        </div>

        <div className="editor">
          <div className="editor-top">
            <span>{selected || 'Nenhum arquivo selecionado'}</span>
            <button onClick={save} disabled={!selected}><Save size={15} /> salvar</button>
          </div>
          <textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="Abra um arquivo do workspace para editar." />
          {status && <p className="muted">{status}</p>}
        </div>
      </div>
    </section>
  );
}

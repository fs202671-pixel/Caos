export type Mode =
  | 'chat'
  | 'code'
  | 'projects'
  | 'teacher'
  | 'memory'
  | 'plugins'
  | 'skills'
  | 'automation'
  | 'image'
  | 'voice'
  | 'modeon'
  | 'dev';

export type Message = {
  id: number;
  role: 'user' | 'ai';
  text: string;
  mode: Mode;
};

export type ToolCard = {
  id: Mode;
  label: string;
  description: string;
  accent: string;
};

export type PlannedAction = {
  id: string;
  title: string;
  description: string;
  risk: 'low' | 'medium' | 'high';
  status: 'draft' | 'needs_confirmation' | 'ready';
};

export type MemoryItem = {
  id: number;
  kind: 'user' | 'project' | 'lesson' | 'system' | 'event';
  text: string;
};

import type { ToolCard } from '../types';

export const tools: ToolCard[] = [
  { id: 'chat', label: 'Chat', description: 'Conversa central com contexto e memória.', accent: 'blue' },
  { id: 'code', label: 'Código', description: 'Cria, explica, refatora e corrige código.', accent: 'cyan' },
  { id: 'projects', label: 'Projetos', description: 'Cria sites, apps e estruturas completas.', accent: 'violet' },
  { id: 'teacher', label: 'Professor', description: 'Ensina passo a passo com plano de estudo.', accent: 'green' },
  { id: 'memory', label: 'Memória', description: 'Guarda, busca e organiza informações.', accent: 'emerald' },
  { id: 'plugins', label: 'Plugins', description: 'Cria novas extensões para a própria IA.', accent: 'amber' },
  { id: 'skills', label: 'Habilidades', description: 'Cria capacidades novas reutilizáveis.', accent: 'pink' },
  { id: 'automation', label: 'Automação', description: 'Monta fluxos e tarefas encadeadas.', accent: 'orange' },
  { id: 'image', label: 'Imagem', description: 'Espaço para criação visual e galerias.', accent: 'purple' },
  { id: 'voice', label: 'Voz', description: 'Espaço para fala, tons e vozes salvas.', accent: 'indigo' },
  { id: 'modeon', label: 'ModeON', description: 'Foco, disciplina e combate à procrastinação.', accent: 'red' },
  { id: 'dev', label: 'Dev Mode', description: 'Arquitetura, logs, permissões e runtime.', accent: 'white' }
];

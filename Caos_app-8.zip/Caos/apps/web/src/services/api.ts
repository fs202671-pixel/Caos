import type { Mode, PlannedAction, MemoryItem } from '../types';

const API_URL = import.meta.env.VITE_CAOS_API_URL || 'http://localhost:8000';

export type WorkspaceItem = { name: string; path?: string; type: 'file' | 'folder' };

export async function sendChat(mode: Mode, message: string, useLocalLlm = false): Promise<{ reply: string; actions: PlannedAction[] }> {
  const response = await fetch(`${API_URL}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ mode, message, use_local_llm: useLocalLlm })
  });
  if (!response.ok) throw new Error('Falha ao falar com a API do Caos.');
  return response.json();
}

export async function getMemory(): Promise<MemoryItem[]> {
  const response = await fetch(`${API_URL}/memory`);
  if (!response.ok) return [];
  const data = await response.json();
  return data.items.map((item: any) => ({ id: item.id, kind: item.kind, text: item.text }));
}

export async function createProject(name: string, description: string, template = 'basic') {
  const response = await fetch(`${API_URL}/projects`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description, template })
  });
  return response.json();
}

export async function createPlugin(name: string, description: string) {
  const response = await fetch(`${API_URL}/plugins`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description })
  });
  return response.json();
}

export async function createSkill(name: string, description: string) {
  const response = await fetch(`${API_URL}/skills`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description })
  });
  return response.json();
}

export async function runPlugin(name: string, input: string) {
  const response = await fetch(`${API_URL}/plugins/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, input })
  });
  return response.json();
}

export async function runSkill(name: string, input: string) {
  const response = await fetch(`${API_URL}/skills/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, input })
  });
  return response.json();
}

export async function startModeOn(goal: string, minutes = 25) {
  const response = await fetch(`${API_URL}/modeon/session`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ goal, minutes })
  });
  return response.json();
}

export async function listWorkspace() {
  const response = await fetch(`${API_URL}/workspace`);
  if (!response.ok) return {};
  return response.json();
}

export async function listFiles(path = ''): Promise<WorkspaceItem[]> {
  const response = await fetch(`${API_URL}/files?path=${encodeURIComponent(path)}`);
  if (!response.ok) return [];
  const data = await response.json();
  return data.items;
}

export async function readFile(path: string): Promise<string> {
  const response = await fetch(`${API_URL}/files/read?path=${encodeURIComponent(path)}`);
  if (!response.ok) throw new Error('Arquivo não encontrado.');
  const data = await response.json();
  return data.content;
}

export async function writeFile(path: string, content: string) {
  const response = await fetch(`${API_URL}/files/write`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path, content })
  });
  return response.json();
}

import type { Mode, PlannedAction } from '../types';

const intro: Record<Mode, string> = {
  chat: 'Vou conversar e manter contexto.',
  code: 'Vou tratar como tarefa de programação.',
  projects: 'Vou estruturar isso como projeto real.',
  teacher: 'Vou explicar como professor, com etapas.',
  memory: 'Vou lidar com memória e recuperação de contexto.',
  plugins: 'Vou planejar um plugin novo para o Caos.',
  skills: 'Vou transformar isso em habilidade reutilizável.',
  automation: 'Vou quebrar em fluxo, gatilhos e ações.',
  image: 'Vou preparar direção visual e geração futura.',
  voice: 'Vou pensar em voz, fala e expressão.',
  modeon: 'Vou focar em disciplina, execução e estado ON.',
  dev: 'Vou analisar arquitetura, risco e permissões.'
};

export function generateReply(mode: Mode, input: string): string {
  const text = input.trim();

  if (!text) return 'Envie uma ordem, ideia ou tarefa. Eu sigo o modo ativo.';

  if (mode === 'teacher') {
    return `${intro[mode]} Tema recebido: "${text}". Vou montar aula, prática, resumo e exercício.`;
  }

  if (mode === 'projects') {
    return `${intro[mode]} Pedido recebido: "${text}". Vou propor estrutura de pastas, arquivos, stack e próximos passos.`;
  }

  if (mode === 'plugins') {
    return `${intro[mode]} Plugin solicitado: "${text}". Vou definir manifesto, permissões, comandos e integração.`;
  }

  if (mode === 'skills') {
    return `${intro[mode]} Habilidade solicitada: "${text}". Vou criar descrição, entrada, saída e exemplos.`;
  }

  if (mode === 'dev') {
    return `${intro[mode]} Vou transformar sua ordem em ação estruturada antes de qualquer mudança.`;
  }

  return `${intro[mode]} Recebi: "${text}".`;
}

export function plan(mode: Mode, input: string): PlannedAction[] {
  const lower = input.toLowerCase();
  const actions: PlannedAction[] = [];

  if (mode === 'projects' || lower.includes('crie um site') || lower.includes('crie um app')) {
    actions.push({
      id: 'create-project',
      title: 'Criar projeto',
      description: 'Gerar estrutura inicial no workspace/projects.',
      risk: 'medium',
      status: 'needs_confirmation'
    });
  }

  if (mode === 'plugins' || lower.includes('plugin')) {
    actions.push({
      id: 'create-plugin',
      title: 'Criar plugin',
      description: 'Gerar manifesto e arquivo base no workspace/plugins.',
      risk: 'medium',
      status: 'needs_confirmation'
    });
  }

  if (mode === 'skills' || lower.includes('habilidade')) {
    actions.push({
      id: 'create-skill',
      title: 'Criar habilidade',
      description: 'Gerar definição reutilizável no workspace/skills.',
      risk: 'medium',
      status: 'needs_confirmation'
    });
  }

  if (lower.includes('apagar') || lower.includes('deletar') || lower.includes('excluir')) {
    actions.push({
      id: 'delete',
      title: 'Ação destrutiva',
      description: 'Qualquer exclusão exige confirmação explícita.',
      risk: 'high',
      status: 'needs_confirmation'
    });
  }

  if (actions.length === 0) {
    actions.push({
      id: 'answer',
      title: 'Responder',
      description: 'Responder sem modificar arquivos.',
      risk: 'low',
      status: 'ready'
    });
  }

  return actions;
}

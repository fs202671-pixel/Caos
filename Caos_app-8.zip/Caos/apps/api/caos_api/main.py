from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Literal, Optional
from pathlib import Path
import json
import os
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.error import URLError

app = FastAPI(title="Caos API", version="1.0-foundation")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Mode = Literal[
    "chat", "code", "projects", "teacher", "memory", "plugins", "skills",
    "automation", "image", "voice", "modeon", "dev"
]

ROOT = Path(__file__).resolve().parents[3]
DATA_DIR = ROOT / "data"
WORKSPACE = ROOT / "workspace"
MEMORY_FILE = DATA_DIR / "memory.json"
LOG_FILE = DATA_DIR / "events.log"

for directory in [
    DATA_DIR,
    WORKSPACE / "projects",
    WORKSPACE / "plugins",
    WORKSPACE / "skills",
    WORKSPACE / "generated",
]:
    directory.mkdir(parents=True, exist_ok=True)

class ChatRequest(BaseModel):
    mode: Mode
    message: str
    use_local_llm: bool = False

class MemoryEntry(BaseModel):
    kind: str
    text: str

class CreateThingRequest(BaseModel):
    name: str
    description: Optional[str] = ""
    template: Optional[str] = "basic"

class FileWriteRequest(BaseModel):
    path: str
    content: str

class FocusSessionRequest(BaseModel):
    minutes: int = 25
    goal: str = "Executar tarefa principal"

class RunRequest(BaseModel):
    name: str
    input: str = ""

def now():
    return datetime.utcnow().isoformat()

def safe_slug(name: str):
    slug = "".join(ch for ch in name.strip().replace(" ", "-") if ch.isalnum() or ch in "-_").strip("-_")
    return slug or "novo-item"

def load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def save_json(path: Path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def log_event(kind: str, payload: dict):
    LOG_FILE.parent.mkdir(exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"at": now(), "kind": kind, "payload": payload}, ensure_ascii=False) + "\n")

def add_memory(kind: str, text: str):
    items = load_json(MEMORY_FILE, [])
    item = {"id": len(items) + 1, "kind": kind, "text": text, "createdAt": now()}
    items.append(item)
    save_json(MEMORY_FILE, items)
    return item

def recent_memory(limit=6):
    return load_json(MEMORY_FILE, [])[-limit:]

def classify_risk(message: str):
    text = message.lower()
    if any(word in text for word in ["apagar", "deletar", "excluir", "remover tudo", "limpar tudo"]):
        return "high"
    if any(word in text for word in ["criar", "editar", "modificar", "arquivo", "plugin", "projeto", "executar"]):
        return "medium"
    return "low"

def infer_actions(mode: Mode, message: str):
    risk = classify_risk(message)
    actions = []

    if mode == "projects" or "crie um site" in message.lower() or "crie um app" in message.lower():
        actions.append({"id": "create-project", "title": "Criar projeto", "description": "Gerar estrutura em workspace/projects.", "risk": "medium", "status": "needs_confirmation"})

    if mode == "plugins" or "plugin" in message.lower():
        actions.append({"id": "create-plugin", "title": "Criar plugin", "description": "Gerar manifesto e arquivo base em workspace/plugins.", "risk": "medium", "status": "needs_confirmation"})

    if mode == "skills" or "habilidade" in message.lower():
        actions.append({"id": "create-skill", "title": "Criar habilidade", "description": "Gerar especificação em workspace/skills.", "risk": "medium", "status": "needs_confirmation"})

    if mode == "code" or "arquivo" in message.lower():
        actions.append({"id": "file-operation", "title": "Operação de arquivo", "description": "Ler ou escrever arquivo dentro do workspace.", "risk": "medium", "status": "needs_confirmation"})

    if risk == "high":
        actions.append({"id": "danger", "title": "Ação destrutiva detectada", "description": "Exige confirmação explícita e escopo exato.", "risk": "high", "status": "needs_confirmation"})

    if not actions:
        actions.append({"id": "reply", "title": "Responder", "description": "Responder sem alterar arquivos.", "risk": "low", "status": "ready"})

    return actions

def system_reply(mode: Mode, message: str):
    memories = recent_memory()
    memory_hint = ""
    if memories:
        memory_hint = " Memória recente: " + " | ".join(item.get("text", "")[:80] for item in memories[-3:])

    base = {
        "chat": "Vou conversar mantendo contexto.",
        "code": "Vou tratar como tarefa de programação.",
        "projects": "Vou transformar isso em estrutura de projeto.",
        "teacher": "Vou ensinar em etapas, com prática e revisão.",
        "memory": "Vou consultar e organizar memória.",
        "plugins": "Vou estruturar um plugin para o Caos.",
        "skills": "Vou criar uma habilidade reutilizável.",
        "automation": "Vou transformar em fluxo de automação.",
        "image": "Vou preparar direção visual.",
        "voice": "Vou preparar expressão de voz.",
        "modeon": "Vou focar em execução e disciplina.",
        "dev": "Vou analisar arquitetura, risco e runtime.",
    }[mode]
    return f"{base} Pedido recebido: {message}.{memory_hint}"

def ask_ollama(prompt: str):
    url = os.environ.get("CAOS_OLLAMA_URL", "http://localhost:11434/api/generate")
    model = os.environ.get("CAOS_OLLAMA_MODEL", "llama3.2")
    payload = json.dumps({"model": model, "prompt": prompt, "stream": False}).encode("utf-8")
    req = Request(url, data=payload, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
            return data.get("response", "")
    except (URLError, TimeoutError, Exception):
        return ""

def ensure_workspace_path(user_path: str):
    clean = user_path.strip().replace("\\", "/").lstrip("/")
    target = (WORKSPACE / clean).resolve()
    workspace_root = WORKSPACE.resolve()
    if workspace_root not in target.parents and target != workspace_root:
        raise HTTPException(status_code=400, detail="Path fora do workspace.")
    return target

def project_files(name: str, description: str, template: str):
    title = name
    if template == "react":
        return {
            "README.md": f"# {title}\n\n{description or 'App React criado pelo Caos.'}\n",
            "package.json": json.dumps({
                "name": safe_slug(name),
                "version": "0.1.0",
                "type": "module",
                "scripts": {"dev": "vite", "build": "vite build"},
                "dependencies": {"@vitejs/plugin-react": "latest", "vite": "latest", "typescript": "latest", "react": "latest", "react-dom": "latest"}
            }, indent=2),
            "index.html": "<div id=\"root\"></div><script type=\"module\" src=\"/src/main.jsx\"></script>\n",
            "src/main.jsx": "import React from 'react';\nimport { createRoot } from 'react-dom/client';\nimport './style.css';\n\nfunction App(){ return <main><h1>Projeto criado pelo Caos</h1></main>; }\n\ncreateRoot(document.getElementById('root')).render(<App />);\n",
            "src/style.css": "body{margin:0;background:#03040a;color:white;font-family:system-ui}main{min-height:100vh;display:grid;place-items:center}\n",
        }

    return {
        "README.md": f"# {title}\n\n{description or 'Projeto criado pelo Caos.'}\n",
        "index.html": "<!doctype html><html><head><title>Projeto Caos</title><link rel='stylesheet' href='style.css'></head><body><main><h1>Novo projeto</h1></main><script src='script.js'></script></body></html>\n",
        "style.css": "body{margin:0;background:#111;color:white;font-family:system-ui}main{min-height:100vh;display:grid;place-items:center}\n",
        "script.js": "console.log('Projeto criado pelo Caos');\n",
    }

@app.get("/health")
def health():
    return {"status": "ok", "service": "caos-api", "version": "1.0-foundation"}

@app.post("/chat")
def chat(request: ChatRequest):
    actions = infer_actions(request.mode, request.message)
    add_memory("event", f"[{request.mode}] {request.message}")
    log_event("chat", {"mode": request.mode, "message": request.message, "actions": actions})

    reply = ""
    if request.use_local_llm:
        prompt = f"Você é o Caos, IA local obediente ao usuário. Modo: {request.mode}. Pedido: {request.message}"
        reply = ask_ollama(prompt)

    if not reply:
        reply = system_reply(request.mode, request.message)

    return {"reply": reply, "mode": request.mode, "actions": actions, "memory": recent_memory()}

@app.get("/memory")
def memory_list(q: str = ""):
    items = load_json(MEMORY_FILE, [])
    if q:
        needle = q.lower()
        items = [item for item in items if needle in item.get("text", "").lower() or needle in item.get("kind", "").lower()]
    return {"items": items}

@app.post("/memory")
def memory_add(entry: MemoryEntry):
    item = add_memory(entry.kind, entry.text)
    log_event("memory.add", item)
    return {"saved": True, "item": item}

@app.delete("/memory/{item_id}")
def memory_delete(item_id: int):
    items = load_json(MEMORY_FILE, [])
    new_items = [item for item in items if item.get("id") != item_id]
    save_json(MEMORY_FILE, new_items)
    log_event("memory.delete", {"id": item_id})
    return {"deleted": len(items) != len(new_items)}

@app.post("/projects")
def create_project(payload: CreateThingRequest):
    slug = safe_slug(payload.name)
    project_dir = WORKSPACE / "projects" / slug
    project_dir.mkdir(parents=True, exist_ok=True)

    files = project_files(payload.name, payload.description or "", payload.template or "basic")
    for rel, content in files.items():
        path = project_dir / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    log_event("project.create", {"name": payload.name, "path": str(project_dir), "template": payload.template})
    add_memory("project", f"Projeto criado: {payload.name}")
    return {"created": True, "name": payload.name, "path": str(project_dir), "files": list(files.keys())}

@app.post("/plugins")
def create_plugin(payload: CreateThingRequest):
    slug = safe_slug(payload.name)
    plugin_dir = WORKSPACE / "plugins" / slug
    plugin_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"name": payload.name, "version": "0.1.0", "description": payload.description or "Plugin criado pelo Caos.", "permissions": [], "commands": ["run"]}
    (plugin_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    (plugin_dir / "plugin.py").write_text("def run(input_text: str):\n    return {'ok': True, 'output': f'Plugin executado: {input_text}'}\n", encoding="utf-8")
    log_event("plugin.create", manifest)
    add_memory("event", f"Plugin criado: {payload.name}")
    return {"created": True, "manifest": manifest, "path": str(plugin_dir)}

@app.post("/skills")
def create_skill(payload: CreateThingRequest):
    slug = safe_slug(payload.name)
    skill_dir = WORKSPACE / "skills" / slug
    skill_dir.mkdir(parents=True, exist_ok=True)
    spec = {"name": payload.name, "description": payload.description or "Habilidade criada pelo Caos.", "input": "texto do usuário", "output": "resultado estruturado", "examples": []}
    (skill_dir / "skill.json").write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    (skill_dir / "README.md").write_text(f"# {payload.name}\n\n{spec['description']}\n", encoding="utf-8")
    log_event("skill.create", spec)
    add_memory("event", f"Habilidade criada: {payload.name}")
    return {"created": True, "skill": spec, "path": str(skill_dir)}

@app.post("/plugins/run")
def run_plugin(payload: RunRequest):
    slug = safe_slug(payload.name)
    plugin_dir = WORKSPACE / "plugins" / slug
    if not plugin_dir.exists():
        raise HTTPException(status_code=404, detail="Plugin não encontrado.")
    return {"ok": True, "output": f"Plugin {payload.name} recebeu: {payload.input}"}

@app.post("/skills/run")
def run_skill(payload: RunRequest):
    slug = safe_slug(payload.name)
    skill_dir = WORKSPACE / "skills" / slug
    spec_file = skill_dir / "skill.json"
    if not spec_file.exists():
        raise HTTPException(status_code=404, detail="Habilidade não encontrada.")
    spec = json.loads(spec_file.read_text(encoding="utf-8"))
    return {"ok": True, "skill": spec.get("name"), "output": f"Habilidade aplicada em: {payload.input}"}

@app.get("/workspace")
def list_workspace():
    result = {}
    for section in ["projects", "plugins", "skills", "generated"]:
        folder = WORKSPACE / section
        items = []
        for p in folder.iterdir():
            if p.is_dir():
                items.append({"name": p.name, "type": "folder"})
            else:
                items.append({"name": p.name, "type": "file"})
        result[section] = items
    return result

@app.get("/files")
def list_files(path: str = ""):
    target = ensure_workspace_path(path)
    if not target.exists():
        return {"items": []}
    if target.is_file():
        return {"items": [{"name": target.name, "path": str(target.relative_to(WORKSPACE)), "type": "file"}]}
    items = []
    for child in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
        items.append({"name": child.name, "path": str(child.relative_to(WORKSPACE)), "type": "folder" if child.is_dir() else "file"})
    return {"items": items}

@app.get("/files/read")
def read_file(path: str):
    target = ensure_workspace_path(path)
    if not target.exists() or not target.is_file():
        raise HTTPException(status_code=404, detail="Arquivo não encontrado.")
    return {"path": str(target.relative_to(WORKSPACE)), "content": target.read_text(encoding="utf-8")}

@app.post("/files/write")
def write_file(payload: FileWriteRequest):
    target = ensure_workspace_path(payload.path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(payload.content, encoding="utf-8")
    log_event("file.write", {"path": payload.path})
    add_memory("event", f"Arquivo escrito: {payload.path}")
    return {"written": True, "path": payload.path}

@app.post("/modeon/session")
def start_focus_session(payload: FocusSessionRequest):
    session = {"goal": payload.goal, "minutes": payload.minutes, "state": "ON", "startedAt": now(), "message": "ModeON ativo. Execute o essencial agora."}
    log_event("modeon.session", session)
    add_memory("event", f"ModeON iniciado: {payload.goal} por {payload.minutes} minutos")
    return session

@app.get("/logs")
def logs():
    if not LOG_FILE.exists():
        return {"events": []}
    lines = LOG_FILE.read_text(encoding="utf-8").splitlines()[-100:]
    return {"events": [json.loads(line) for line in lines if line.strip()]}

# Scripts

Espaço para scripts auxiliares.

Ideias futuras:

- gerar novo plugin
- gerar nova habilidade
- criar projeto pelo terminal
- rodar testes
- empacotar release
